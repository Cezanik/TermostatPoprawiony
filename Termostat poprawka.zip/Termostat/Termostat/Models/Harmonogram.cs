﻿using System.ComponentModel.DataAnnotations;

namespace Termostat.Models
{
    public class Harmonogram : IValidatableObject
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Nazwa jest wymagana.")]
        [MaxLength(50, ErrorMessage = "Nazwa nie może być dłuższa niż 50 znaków.")]
        public string Nazwa { get; set; }
        [Required(ErrorMessage = "Pole obowiązkowe ")]
        [Range(0, 23, ErrorMessage = "Wartość Start musi być między 0 a 23.")]
        public int Start { get; set; }
        [Required(ErrorMessage = "Pole obowiązkowe ")]
        [Range(1, 24, ErrorMessage = "Wartość End musi być między 1 a 24.")]
        public int End { get; set; }
        [Required(ErrorMessage = "Pole obowiązkowe ")]
        [Range(18, 35, ErrorMessage = "Docelowa temperatura musi być między 18 a 35.")]
       
        public int DocelowaTemperatura { get; set; }
        public bool IsActive { get; set; } = true; 

        [Required]
        public int MieszkanieId { get; set; }

        public virtual Mieszkanie? Mieszkanie { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (Start >= End)
            {
                yield return new ValidationResult(
                    "Wartość 'Start' musi być mniejsza niż 'End'.",
                    new[] { nameof(Start), nameof(End) });
            }
        }
      
    }
    public class HarmonogramViewModel
    {
        public Harmonogram Harmonogram { get; set; }
        public decimal CenaDzienna { get; set; }
        public decimal CenaTygodniowa { get; set; }
        public decimal CenaMiesieczna { get; set; }
    }
    public class PodsumowanieKosztowViewModel
    {
        public decimal LacznyKosztDzienny { get; set; }
        public decimal LacznyKosztTygodniowy { get; set; }
        public decimal LacznyKosztMiesieczny { get; set; }
    }
}
